<?php
 $smarty->caching = false;
 $smarty->display('404.dwt');
